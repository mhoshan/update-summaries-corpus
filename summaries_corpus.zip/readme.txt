
Contents:

=========
- README file: This file
.
- 183 Arabic text files (Articles).
- 21 human generated summaries 

The dataset:

============

The corpus contain two main parts the articles and their correspondence reference summaries. They were constructed using 186 Arabic articles, covering different domains: politic, sport, science, economic, culture and technology.These articles were collected using Google Custom Search API from various mediums, such as: news agencies, newspaper, and a news search engine.The sites that been used:

spa.gov.sa
emaratalyoum.com
masress.com
aljazeera.com
alhayat.com


Each article is tagged by the publishing date, and each related articles are grouped by the query that been used to retrieve them.


Twenty-two summaries were created with help of three human experts,  whose native language is Arabic, with a graduate degree in Arabic Language.The date that been used was the date of the latest article for each group.All texts are encoded in UTF-8.The total size of the dataset is 1.43 MB.

Articles text Format:
=====================
the format used for all article text files: 
-Article's date
-Article's title(some titles are missing)
-Article's body

For Contact:
============
Muneera Alhoshan
malhawshan@kacst.edu.sa

